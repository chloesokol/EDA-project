### Data Source
#The data is composed of “selected health-related Sustainable Development Goal (SDG) 
#indicators and selected 13th General Program of Work (GPW13) indicators”. Missing data 
#values are denoted as “- “. Indicators that site a period of years as opposed to a 
#singular year, present data values from the most recent year within the range. Alongside 
#these selected indicators are chosen health measurements, such as population counts, to 
#provide a more general view of the state of a country at that time. Additionally, the 
#type of data for each variable is noted, whether as a comparable estimate or as primary 
#data. Comparable estimates are used for countries where primary data is limited. Direct 
#data on uncertainty can be found on the WHO Global Health Observatory site. The excel 
#file of the data set is spread among four annexes, which were combined.

# Data Tidying Done Directly On The Excel Workbook
#The data was joined together from the four annexes into a single data table. Each annex was 
#formatted originally with the exact same list of member states, as well as WHO regions and global 
#categories. Each sub data set was copied and pasted next to each other in a new excel file 
#with any spacing removed. Additional space was removed from the overall table between WHO 
#member states and global data, and between certain columns that were separated. In 
#addition, all missing data was changed from “- “ to an empty cell, as R understands “NA” 
#values with read-in excel files. The last thing that was altered was column titles. There 
#was a format that combined matching dates of neighboring columns with an extra row of column 
#titles. To format this file along the guidelines of tidy data, each column needed to have 
#one column title, complete with the variable name (which were abbreviated for easy 
#access later during data manipulation), data type, and year all in one cell. A code book was 
#created with each new, abbreviated column name and the description of the true variable. 

# Looking at Missing Data
#By using `skim()` on the whs dataset, we can see that there is missing data in every variable
#except "member_state", "pop_both19" (the combined male and female population), "NTDs19" 
#(the number of people requiring interventions against NTDs), and "DTP319" 
#(Diphtheria-tetanus-pertussis (DTP3) immunization coverage among 1-year-olds). Variables
#missing over 20% of their data is questionable for variable-wide comparison, though most 
#exploratory data analysis was done on the observations for regions of member states, which
#is much more reliable to have real observations. Since there are 201 unique values for 
#`member_state`, a variable with questionable data for comparison among all member states
#has more than 40 missing observations (20%). These variables include "new_HIV2019", "malaria19",
#"modern_methods11_20", "over10_health_exp11_18", "over25_health_exp11_18", "u15_tobacco18",
#"medical_research19", "health_facilities11_19", "pharmacist_density11_19", "MRSA19",
#"Ecoli19", "u5_wasting11_20", "development_assistance19", "violence_lifetime18", 
#"safe_drinking17", "sanitation17", "hand_washing17", "gov_sanitation19", "PCV319", and 
#"HPV19". If close to 80% of the data is available for a variable, evaluation of results
#should be fine, with note of missing data, but modeling should not be done on these 
#variables. Data with over 50% of data missing should never be used for evaluation over 
#the whole variable. These variables are missing more than 100 values: 
#"over10_health_exp11_18", "over25_health_exp11_18", "health_facilities11_19", "MRSA19", 
#"Ecoli19", "sanitation17", "hand_washing17", and "HPV19". 
